﻿namespace OsEngine.Market.Servers.Binance.Spot.BinanceSpotEntity
{
    public class BinanceTime
    {
        public long serverTime { get; set; }
    }
}