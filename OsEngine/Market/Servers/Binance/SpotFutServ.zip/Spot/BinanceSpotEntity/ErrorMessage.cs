﻿namespace OsEngine.Market.Servers.Binance.Spot.BinanceSpotEntity
{
    public class ErrorMessage
    {
        public int code { get; set; }
        public string msg { get; set; }
    }
}