﻿namespace OsEngine.Market.Servers.Binance.Spot.BinanceSpotEntity
{
    public class ListenKey
    {
        public string listenKey { get; set; }
    }
}