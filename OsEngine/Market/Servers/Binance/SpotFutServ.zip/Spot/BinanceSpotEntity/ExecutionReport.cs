﻿namespace OsEngine.Market.Servers.Binance.Spot.BinanceSpotEntity
{
    public class ExecutionReport
    {
        public string e { get; set; }
        public string E { get; set; }
        public string s { get; set; }
        public string c { get; set; }
        public string S { get; set; }
        public string o { get; set; }
        public string f { get; set; }
        public string q { get; set; }
        public string p { get; set; }
        public string P { get; set; }
        public string F { get; set; }
        public string g { get; set; }
        public string C { get; set; }
        public string x { get; set; }
        public string X { get; set; }
        public string r { get; set; }
        public string i { get; set; }
        public string l { get; set; }
        public string z { get; set; }
        public string L { get; set; }
        public string n { get; set; }
        public object N { get; set; }
        public string T { get; set; }
        public string t { get; set; }
        public string I { get; set; }
        public bool w { get; set; }
        public bool m { get; set; }
        public bool M { get; set; }
        public string O { get; set; }
        public string Z { get; set; }
    }
}